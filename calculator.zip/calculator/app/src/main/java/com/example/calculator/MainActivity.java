
package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    EditText etFNumber;  // First number input field
    EditText etSNumber;  // Second number input field
    TextView tvResult;   // TextView to display the result

    // Variables to store numbers and result string
    double num1, num2;
    String result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the EditText and TextView by linking them to the layout
        etFNumber = findViewById (R.id.et_fNumber);
        etSNumber = findViewById(R.id.et_sNumber);
        tvResult = findViewById(R.id.tv_result);
    }

    /**
     * Helper method to retrieve numbers from EditText inputs and validate them.
     * return true if inputs are valid, false otherwise.
     */
    private boolean getNumbers() {
        String first = etFNumber.getText().toString().trim();  // Get text from first EditText
        String second = etSNumber.getText().toString().trim(); // Get text from second EditText

        // Check if any input is empty
        if (first.isEmpty() || second.isEmpty()) {
            Toast.makeText(this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Try to parse the input strings into doubles
        try {
            num1 = Double.parseDouble(first);
            num2 = Double.parseDouble(second);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid number format", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true; // Input is valid
    }

    // Listener for the Add button
    public void btnAddListener(View v) {
        if (getNumbers()) {
            double sum = num1 + num2;
            result = num1 + " + " + num2 + " = " + sum;
            tvResult.setText(result); // Display the result
        }
    }

    // Listener for the Subtract button
    public void btnSubtractListener(View  v) {
        if (getNumbers()) {
            double subtract = num1 - num2;
            result = num1 + " - " + num2 + " = " + subtract;
            tvResult.setText(result); // Display the result
        }
    }

    // Listener for the Multiply button
    public void btnMultiplyListener(View v) {
        if (getNumbers()) {
            double multiply = num1 * num2;
            result = num1 + " × " + num2 + " = " + multiply;
            tvResult.setText(result); // Display the result
        }
    }

    // Listener for the Divide button
    public void btnDivideListener(View v) {
        if (getNumbers()) {
            // Check for division by zero
            if (num2 != 0) {
                double divide = num1 / num2;
                result = num1 + " ÷ " + num2 + " = " + divide;
            } else {
                // Show error message as Toast instead of TextView
                Toast.makeText(this, "Cannot divide by zero!", Toast.LENGTH_SHORT).show();
            }
            tvResult.setText(result); // Display the result or error
        }
    }
}
